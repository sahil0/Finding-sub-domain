4.1.1 - 2017-09-05
====================
- added -f or --csvfileds option to add fields name to the first row of csv output file.

4.1 - 2017-08-07
====================
- added VirusTotal support. Setting the API_KEY within the config.json file

4.0 - 2017-02-03
====================
- release v.4.0.0

4.0 beta - 2016-12-16
====================

- rewrited code and options
- removed option -z
- new -c or --csv option to export CSV output
- new -j or --json option to export full output in JSON

3.0 rc1 - 2014-02-21
====================

- release v.3.0 rc1

2.0 - 2014-02-20
================

- rewrite code and options
- detect ALIAS name
- automatic wildcard bypass
- resolve single domain

1.x - 2011
==========

- old version on Google Code -> http://code.google.com/p/knock/
